# ErgoPraxis (Praxeology: means–ends)
Purpose: means–end reasoning and plan composition.
Status: v0.1 scaffold, zero admits.

# Axiopraxis (Axiology: beauty/value)
Purpose: value and aesthetic constraints as a modal overlay.
Status: v0.1 scaffold, zero admits.
